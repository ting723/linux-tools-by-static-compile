/*
 * Win32-specific version for manual manipulation.
 */

#define USE_PCRE                     0
#define USE_IPv6                     1

#define HAVE_DLT_RAW                 1
#define HAVE_DLT_LOOP                1
#define HAVE_DLT_LINUX_SLL           1
#define HAVE_DLT_IEEE802_11          1
#define HAVE_DLT_IEEE802_11_RADIO    1

#define HAVE_DUMB_UDPHDR             0

#define USE_PCAP_RESTART             0
#define PCAP_RESTART_FUNC            0

#define USE_DROPPRIVS                0
#define DROPPRIVS_USER               "notused"

