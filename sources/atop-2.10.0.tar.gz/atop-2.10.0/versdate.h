#ifndef __ATOP_VERSDATA__
#define __ATOP_VERSDATA__
#define	ATOPDATE	"2024/01/04 10:52:30"
#endif
