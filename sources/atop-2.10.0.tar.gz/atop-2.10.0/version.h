#ifndef __ATOP_VERSION__
#define __ATOP_VERSION__

#define	ATOPVERS	"2.10.0"

char *getstrvers(void);
unsigned short getnumvers(void);

#endif
